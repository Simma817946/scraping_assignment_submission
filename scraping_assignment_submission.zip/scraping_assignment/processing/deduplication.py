import hashlib
import re


def normalize_for_fingerprint(value):
    value = str(value or "").lower()
    value = re.sub(r"[^\w\s]", "", value)
    return " ".join(value.split())


def make_fingerprint(record):
    if record.get("source") == "Books to Scrape":
        key = "{} {}".format(record.get("source"), record.get("name_or_title", ""))
    else:
        key = "{} {} {}".format(
            record.get("source"),
            record.get("author", ""),
            str(record.get("name_or_title", ""))[:50],
        )
    return hashlib.sha256(normalize_for_fingerprint(key).encode("utf-8")).hexdigest()


def find_duplicates(records):
    seen, unique, duplicates = set(), [], []
    for record in records:
        fingerprint = make_fingerprint(record)
        if fingerprint in seen:
            duplicates.append(record)
        else:
            seen.add(fingerprint)
            unique.append(record)
    return unique, duplicates
