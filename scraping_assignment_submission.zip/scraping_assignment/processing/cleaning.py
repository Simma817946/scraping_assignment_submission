import re
from urllib.parse import urlparse

RATING_MAP = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}


def clean_text(value):
    if value is None:
        return None
    text = " ".join(str(value).replace("\xa0", " ").split())
    return text or None


def strip_quotes(value):
    text = clean_text(value)
    return text.strip("“”\"") if text else None


def clean_price(raw):
    if raw is None or not str(raw).strip():
        return None
    match = re.search(r"\d+(?:,\d{3})*(?:\.\d+)?", str(raw))
    return float(match.group().replace(",", "")) if match else None


def clean_rating(raw):
    if raw is None:
        return None
    for word, number in RATING_MAP.items():
        if re.search(r"\b" + re.escape(word) + r"\b", str(raw).lower()):
            return number
    return None


def clean_tags(tags):
    if tags is None:
        return None
    values = [tags] if isinstance(tags, str) else list(tags)
    cleaned = sorted({clean_text(x).lower() for x in values if clean_text(x)})
    return ";".join(cleaned) if cleaned else None


def normalize_url(url):
    if not url:
        return None
    value = str(url).strip()
    parsed = urlparse(value)
    return value if parsed.scheme in ("http", "https") and parsed.netloc else None


def clean_record(record):
    return {
        "source": clean_text(record.get("source")),
        "source_url": normalize_url(record.get("source_url")),
        "name_or_title": strip_quotes(record.get("name_or_title")),
        "category": clean_text(record.get("category")),
        "price": clean_price(record.get("price")),
        "rating": clean_rating(record.get("rating")),
        "author": clean_text(record.get("author")),
        "tags": clean_tags(record.get("tags")),
        "description": clean_text(record.get("description")),
        "scraped_at": clean_text(record.get("scraped_at")),
    }
