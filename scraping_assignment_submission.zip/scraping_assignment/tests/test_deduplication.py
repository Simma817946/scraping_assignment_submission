from processing.deduplication import find_duplicates, make_fingerprint


def test_duplicates_ignore_case_and_spaces():
    base = {"source": "Books to Scrape", "author": None}
    records = [
        dict(base, name_or_title="Example Book Title"),
        dict(base, name_or_title="  Example Book Title "),
        dict(base, name_or_title="EXAMPLE BOOK TITLE"),
    ]
    unique, duplicates = find_duplicates(records)
    assert len(unique) == 1
    assert len(duplicates) == 2


def test_fingerprint_is_same_after_normalization():
    a = {"source": "Books to Scrape", "name_or_title": "Example Book"}
    b = {"source": "Books to Scrape", "name_or_title": " example book "}
    assert make_fingerprint(a) == make_fingerprint(b)
