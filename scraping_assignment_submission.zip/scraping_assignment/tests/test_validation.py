from processing.validation import validate_record


def record():
    return {
        "source": "Books to Scrape",
        "source_url": "https://books.toscrape.com/catalogue/test/index.html",
        "name_or_title": "Test Book",
        "price": 10.5,
        "rating": 4,
    }


def test_valid_record():
    assert validate_record(record()) == []


def test_invalid_url():
    item = record()
    item["source_url"] = "not-a-url"
    assert "invalid_url" in validate_record(item)


def test_invalid_rating():
    item = record()
    item["rating"] = 7
    assert "invalid_rating" in validate_record(item)


def test_missing_name():
    item = record()
    item["name_or_title"] = None
    assert "missing_name" in validate_record(item)
