import logging
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .base_scraper import BaseScraper

logger = logging.getLogger(__name__)
START_URL = "https://books.toscrape.com/"


class BooksScraper(BaseScraper):
    SOURCE = "Books to Scrape"

    def parse_book(self, article, page_url):
        link = article.select_one("h3 > a")
        price = article.select_one("p.price_color")
        rating = article.select_one("p.star-rating")
        availability = article.select_one("p.instock.availability")

        if not link or not link.get("href"):
            raise ValueError("Missing book title or URL")

        return {
            "source": self.SOURCE,
            "source_url": urljoin(page_url, link["href"]),
            "name_or_title": link.get("title") or link.get_text(" ", strip=True),
            "category": None,
            "price": price.get_text(" ", strip=True) if price else None,
            "rating": " ".join(rating.get("class", [])) if rating else None,
            "author": None,
            "tags": None,
            "description": None,
        }

    def parse_page(self, html, page_url):
        soup = BeautifulSoup(html, "lxml")
        records = []
        for article in soup.select("article.product_pod"):
            try:
                records.append(self.parse_book(article, page_url))
            except (ValueError, AttributeError, TypeError) as exc:
                logger.warning("Skipping malformed book on %s: %s", page_url, exc)
        return records

    def scrape(self):
        url = START_URL
        page = 1
        records = []
        while url:
            logger.info("Books page %d: %s", page, url)
            response = self.get(url)
            if response is None:
                logger.error("Stopping Books scraper after page %d failed", page)
                break
            page_records = self.parse_page(response.text, url)
            records.extend(page_records)
            soup = BeautifulSoup(response.text, "lxml")
            next_link = soup.select_one("li.next > a")
            url = urljoin(url, next_link["href"]) if next_link and next_link.get("href") else None
            page += 1
        logger.info("Books total records collected: %d", len(records))
        return records
