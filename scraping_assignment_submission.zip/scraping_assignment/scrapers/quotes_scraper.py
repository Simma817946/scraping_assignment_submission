import logging
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .base_scraper import BaseScraper

logger = logging.getLogger(__name__)
START_URL = "https://quotes.toscrape.com/"


class QuotesScraper(BaseScraper):
    SOURCE = "Quotes to Scrape"

    def parse_quote(self, quote, page_url):
        text = quote.select_one("span.text")
        author = quote.select_one("small.author")
        if not text or not author:
            raise ValueError("Missing quote text or author")

        tags = [tag.get_text(" ", strip=True) for tag in quote.select("a.tag")]
        return {
            "source": self.SOURCE,
            "source_url": page_url,
            "name_or_title": text.get_text(" ", strip=True),
            "category": None,
            "price": None,
            "rating": None,
            "author": author.get_text(" ", strip=True),
            "tags": tags,
            "description": None,
        }

    def parse_page(self, html, page_url):
        soup = BeautifulSoup(html, "lxml")
        records = []
        for quote in soup.select("div.quote"):
            try:
                records.append(self.parse_quote(quote, page_url))
            except (ValueError, AttributeError, TypeError) as exc:
                logger.warning("Skipping malformed quote on %s: %s", page_url, exc)
        return records

    def scrape(self):
        url = START_URL
        page = 1
        records = []
        while url:
            logger.info("Quotes page %d: %s", page, url)
            response = self.get(url)
            if response is None:
                logger.error("Stopping Quotes scraper after page %d failed", page)
                break
            page_records = self.parse_page(response.text, url)
            records.extend(page_records)
            soup = BeautifulSoup(response.text, "lxml")
            next_link = soup.select_one("li.next > a")
            url = urljoin(url, next_link["href"]) if next_link and next_link.get("href") else None
            page += 1
        logger.info("Quotes total records collected: %d", len(records))
        return records
