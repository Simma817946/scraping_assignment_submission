import logging
import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


class BaseScraper:
    def __init__(self, delay=0.5, timeout=15):
        self.delay = delay
        self.timeout = timeout
        self.session = self._create_session()

    @staticmethod
    def _create_session():
        session = requests.Session()
        session.headers.update({
            "User-Agent": "RealisierenTechnologiesScrapingAssignment/1.0 (educational project)"
        })
        retry = Retry(
            total=3,
            connect=3,
            read=3,
            status=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=frozenset(["GET"]),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def get(self, url):
        try:
            logger.info("Request: %s", url)
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            response.encoding = "utf-8"
            return response
        except requests.RequestException as exc:
            logger.error("Request failed: %s | %s", url, exc)
            return None
        finally:
            time.sleep(self.delay)

    def close(self):
        self.session.close()
